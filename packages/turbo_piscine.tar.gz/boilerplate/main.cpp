#include <iostream>

int main(void) {
    std::cout << "Hello world\n";
}
